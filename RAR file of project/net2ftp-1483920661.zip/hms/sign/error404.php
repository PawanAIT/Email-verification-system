﻿<?php 
echo file_get_contents("http://www.tinsanity.net/404.shtml");

 ?>